close all
clear all     
%clc





% Parameters
global L Ee EE  s0 k0_init N U t E_st DATA    %#ok<TLEV>
Tmax =51;   % Number of generetions
run=4;   % Number of runs

col = 'rbcgmk';  




L = 100;        % Number of sites per genome
N = 1e4;        % Number of genomes
coef=0.05;      % Average selection coefficient

sigma=coef*sqrt(pi/2);  % standard deviation for half gaussian distribution

s0 = 10;        % is not needed here: we use 'half' distribution
a = 0;          % percentage of beneficial. Here all mutations are deleterious.
     

U = 0.05;     
muL = U;        % per genome
mu=muL/L;       % per site

%% define EPISTATIC TOPOLOGY is not needed here

E_st = 0; % no epistasis

EE = zeros(L,L);

for i = 2:2:L                    %% 2 is <p> = 1, increase to skip pairs 
    EE(i,i-1) = 1; 
    EE(i-1,i) = 1;
end

Ee = tril(EE,-1);                % lower triangular matrix

%%


% f_init is initial mutation frequency per site over population 

f_init=0.2;%[0.01 0.05 0.1 0.15 0.2 0.25 0.3]  % initial value of mutant frequency per site

 k0_init= f_init*L;

 %Initialization
 
ww_r=zeros(N,Tmax,run);
ww_mean_run=zeros(N,Tmax);

W_r=zeros(Tmax,run);
fw_r=zeros(Tmax,run);
f_r=zeros(Tmax,run);

F1_r=zeros(L,Tmax,run);
F0_r=zeros(L,Tmax,run);

F1 = zeros(L,Tmax); 
F0 = zeros(L,Tmax);

beta_r=zeros(Tmax,run);


W=zeros(1,Tmax);
f=zeros(1,Tmax);
fw=zeros(1,Tmax);
beta=zeros(1,Tmax);
slope_an=zeros(1,Tmax);
slope_f_beta=zeros(1,Tmax);

F1_all_mean=zeros(run,L);

minFitness=zeros(1,Tmax);

f_s=zeros(L,Tmax);

f_beta=zeros(L,Tmax);

f_an=zeros(L,Tmax);


f_w_s=zeros(N,Tmax);
beta_s=zeros(N,Tmax);
f_f0_s=zeros(N,L,Tmax);
f_s_r=zeros(L,Tmax,run);

load('myrng.mat');


%ss=rng('shuffle');
                                                                
    for r=1:run
    
%rand('seed', 1);
      
      disp("run "+r)
    
      % ww - matrix of genome fitnesses over time
      % S - vector of selection coefficients
      % DATA - 3D binary matrix of genomes (0 - best fit allele, 1 - less fit
      % allele) over time
    
      [DATA, ww, S] = evolution_code('half',  s0,  a, L, N,  Tmax,  2,   U, k0_init , 1 , E_st, Ee, coef,ss);   


% Check which regime 

       c_1 = N * (mu/abs(mean(S)))^2;
        
       SUlogNs = abs(mean(S))/(mu*L)*log(N*abs(mean(S)));


        for tt=1:Tmax 
            
            

            
            
            
            ww_r(:,tt,r) = ww(:,tt);   
            
            fw_s(:,tt) = abs(ww(:,tt)./(mean(S)*L));
            
            beta_s(:,tt) = sqrt(2/(pi*(-mean(S))^2).*1./fw_s(:,tt)); 

            W_r(tt,r) = mean(ww(:,tt));                 % Average fitness over population
            fw_r(tt,r) = abs(W_r(tt,r)./(mean(S)*L));   % Fitness frequency normalized by selec coef
                              % Sequences


            for jj = 1:L
    
                    F1_r(jj,tt,r) = length(find(DATA(:,jj,tt)==1))/N;
                    F0_r(jj,tt,r) = 1-F1_r(jj,tt,r);
                    

                    f_f0_s(:,jj,tt)=exp(beta_s(:,tt).*S(jj))./(1+exp(beta_s(:,tt).*S(jj)));
            end
            
                 for jj = 1:L                
                    f_s_r(jj,tt,r)=mean(f_f0_s(:,jj,tt));
                    f_an(jj,tt)=f_init./((1-f_init)*exp(-(tt-1)*S(jj))+f_init);

                 end

                f_r(tt,r) = mean(F1_r(:,tt,r));  % Average frequency over sites
  
        end
        
        
     
    end
    
  %%  

    
    slope_exponential_fit=0; 
    A=0;
      
    f0max_entropy=0;
    
    %slope_an=0;
    
   

  for tt=1:Tmax

        W(tt)=mean(W_r(tt,:));          % Average fitness over genomes and runs
        f(tt)=mean(f_r(tt,:));          % Average frequency over sites and runs
        fw(tt)=mean(fw_r(tt,:));

    for jj=1:L
    
        F1(jj,tt)=mean(F1_r(jj,tt,:));
        F0(jj,tt)=mean(F0_r(jj,tt,:));
        
        f_s(jj,tt)=mean(f_s_r(jj,tt,:));  % Average analytic frequency over runs at each site

   
    end 
    
    for ii=1:N
         ww_mean_run(ii,tt)=mean(ww_r(ii,tt,:));

    end
    
    
 
       
    end


    %%
 %close all        

figure(2) % figure 2A-E in the paper

tt=10;   % time point to plot

mat = DATA(1:100:1e4,:,tt);  % Your sample matrix
[r, c] = size(mat);                          % Get the matrix size
imagesc((1:c)+0.5, (1:r)+0.5, mat);          % Plot the image
colormap(parula);                              % Use a gray colormap
axis equal                                   % Make axes grid sizes equal
set(gca, 'XTick', 1:c, 'YTick', 1:r, ...      % Change some axes properties
         'XLim', [1 c+1], 'YLim', [1 r+1], ...
         'GridLineStyle', '-', 'XGrid', 'on', 'YGrid', 'on');
     
 title({['t=' num2str(tt-1)]},'FontSize', 20)
xticks([13 31  47 60 74  90 99])
yticks([1 10 20 30 40 50 60 70 80 90 100])
xticklabels({num2str(-S(13)*100,'%0.0f'), num2str(-S(31)*100,'%0.0f'), num2str(-S(47)*100,'%0.0f'), num2str(-S(60)*100,'%0.0f'), num2str(-S(74)*100,'%0.0f'), num2str(-S(90)*100,'%0.0f') , num2str(-S(99)*100,'%0.0f')})
xtickangle(0)
 % XTicksAt = [num2str(-S(1)), num2str(-S(10)), num2str(-S(20)), num2str(-S(30)), num2str(-S(40))])
xlabel('Mutation cost in fitness, s {\bf\times} 100','FontSize',30)
  ylabel('Genome number in sample','FontSize',30)
  grid off
  set(gca,'FontSize',25)
    set(gca,'linewidth',1.5)
    
  
         %%
        