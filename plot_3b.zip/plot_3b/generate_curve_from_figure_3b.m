close all
clear all     
%clc





% Parameters
global L Ee EE  s0 k0_init N U t E_st DATA    %#ok<TLEV>
Tmax =51;   % Number of generetions
run=4;   % Number of runs

col = 'rbcgmk';  




L = 100;        % Number of sites per genome
N = 1e4;        % Number of genomes
coef=0.05;      % Average selection coefficient

sigma=coef*sqrt(pi/2);  % standard deviation for half gaussian distribution

s0 = 10;        % is not needed here: we use 'half' distribution
a = 0;          % percentage of beneficial. Here all mutations are deleterious.
     

U = 0.05;     
muL = U;        % per genome
mu=muL/L;       % per site

%% define EPISTATIC TOPOLOGY is not needed here

E_st = 0; % no epistasis

EE = zeros(L,L);

for i = 2:2:L                    %% 2 is <p> = 1, increase to skip pairs 
    EE(i,i-1) = 1; 
    EE(i-1,i) = 1;
end

Ee = tril(EE,-1);                % lower triangular matrix

%%


% f_init is initial mutation frequency per site over population 

f_init=0.2;%[0.01 0.05 0.1 0.15 0.2 0.25 0.3]  % initial value of mutant frequency per site

 k0_init= f_init*L;

 %Initialization
 
ww_r=zeros(N,Tmax,run);
ww_mean_run=zeros(N,Tmax);

W_r=zeros(Tmax,run);
fw_r=zeros(Tmax,run);
f_r=zeros(Tmax,run);

F1_r=zeros(L,Tmax,run);
F0_r=zeros(L,Tmax,run);

F1 = zeros(L,Tmax); 
F0 = zeros(L,Tmax);

beta_r=zeros(Tmax,run);


W=zeros(1,Tmax);
f=zeros(1,Tmax);
fw=zeros(1,Tmax);
beta=zeros(1,Tmax);
slope_an=zeros(1,Tmax);
slope_f_beta=zeros(1,Tmax);

F1_all_mean=zeros(run,L);

minFitness=zeros(1,Tmax);

f_s=zeros(L,Tmax);

f_beta=zeros(L,Tmax);

f_an=zeros(L,Tmax);


f_w_s=zeros(N,Tmax);
beta_s=zeros(N,Tmax);
f_f0_s=zeros(N,L,Tmax);
f_s_r=zeros(L,Tmax,run);

load('myrng.mat');


%ss=rng('shuffle');
                                                                
    for r=1:run
    
%rand('seed', 1);
      
      disp("run "+r)
    
      % ww - matrix of genome fitnesses over time
      % S - vector of selection coefficients
      % DATA - 3D binary matrix of genomes (0 - best fit allele, 1 - less fit
      % allele) over time
    
      [DATA, ww, S] = evolution_code('half',  s0,  a, L, N,  Tmax,  2,   U, k0_init , 1 , E_st, Ee, coef,ss);   


% Check which regime 

       c_1 = N * (mu/abs(mean(S)))^2;
        
       SUlogNs = abs(mean(S))/(mu*L)*log(N*abs(mean(S)));


        for tt=1:Tmax 
            
            

            
            
            
            ww_r(:,tt,r) = ww(:,tt);   
            
            fw_s(:,tt) = abs(ww(:,tt)./(mean(S)*L));
            
            beta_s(:,tt) = sqrt(2/(pi*(-mean(S))^2).*1./fw_s(:,tt)); 

            W_r(tt,r) = mean(ww(:,tt));                 % Average fitness over population
            fw_r(tt,r) = abs(W_r(tt,r)./(mean(S)*L));   % Fitness frequency normalized by selec coef
                              % Sequences


            for jj = 1:L
    
                    F1_r(jj,tt,r) = length(find(DATA(:,jj,tt)==1))/N;
                    F0_r(jj,tt,r) = 1-F1_r(jj,tt,r);
                    

                    f_f0_s(:,jj,tt)=exp(beta_s(:,tt).*S(jj))./(1+exp(beta_s(:,tt).*S(jj)));
            end
            
                 for jj = 1:L                
                    f_s_r(jj,tt,r)=mean(f_f0_s(:,jj,tt));
                    f_an(jj,tt)=f_init./((1-f_init)*exp(-(tt-1)*S(jj))+f_init);

                 end

                f_r(tt,r) = mean(F1_r(:,tt,r));  % Average frequency over sites
  
        end
        
        
     
    end
    
  %%  

    
    slope_exponential_fit=0; 
    A=0;
      
    f0max_entropy=0;
    
    %slope_an=0;
    
   

  for tt=1:Tmax

        W(tt)=mean(W_r(tt,:));          % Average fitness over genomes and runs
        f(tt)=mean(f_r(tt,:));          % Average frequency over sites and runs
        fw(tt)=mean(fw_r(tt,:));

    for jj=1:L
    
        F1(jj,tt)=mean(F1_r(jj,tt,:));
        F0(jj,tt)=mean(F0_r(jj,tt,:));
        
        f_s(jj,tt)=mean(f_s_r(jj,tt,:));  % Average analytic frequency over runs at each site

   
    end 
    
    for ii=1:N
         ww_mean_run(ii,tt)=mean(ww_r(ii,tt,:));

    end
    
    
   
    

                                                
ft = fittype('aa*exp(bb*x)');

f1fit = fit(-S',F1(:,tt),ft);    % fitting data

fit_fs = fit(-S',f_s(:,tt),ft);  % fitting analytics

slope_an(tt)=fit_fs.bb;

sigma=coef*sqrt(pi/2);   % std for half normal 

A=vertcat(A,f1fit.aa);   


slope_exponential_fit=vertcat(slope_exponential_fit,f1fit.bb);   % slope from fitting data




minFitness(tt)=min(ww_mean_run(:,tt))/(mean(S)*L);

f0=0.001:0.001:minFitness(tt);


g0=2/(pi);   % 

g_entropy = -(f0-f_init).^2./(2*(2*(1-1/pi)*(1-f_init).*f_init+(1-2/pi).*f_init))-tt*f0*coef+2*sqrt(g0.*f0);

[maxg, indf0max]=max(g_entropy);

f0max_entropy=vertcat(f0max_entropy,f0(indf0max));


         beta_f(tt) = sqrt(2/(pi)*1/(fw(tt)*f_init));%*(-mean(S));
         %beta(tt) = 1/2*(sqrt(2/(pi))*1/(-mean(S))*1/sigma*1/fw(tt)^2)^(1/3);
         beta(tt) = sqrt(2/(pi).*1./f0(indf0max));%*(-mean(S));

         beta_2(tt) = sqrt(2/(pi*(-mean(S))^2)*1/fw(tt));%*(-mean(S));
         
         f_beta(:,tt) = exp(S(:).*beta_2(tt))./(1+exp(S(:).*beta_2(tt)));
         

         fit_f_beta = fit(S',f_beta(:,tt),ft); 
         slope_f_beta(tt)=fit_f_beta.bb;
       
    end
             slope_exponential_fit=slope_exponential_fit(2:length(slope_exponential_fit));
             A=A(2:length(A));
             
             %slope_an=slope_an(2:length(slope_an));

             f0max_entropy=f0max_entropy(2:length(f0max_entropy));

             T=1:Tmax;
            % Ct=C'./T;

    %%

 figure(3) % Figure 3b in the paper
       
         
         
         
         plot(0:Tmax-1,-slope_exponential_fit,'b','Linewidth',2)

         axis([0 50 0 50])
         
         
         axis square



         xlabel('Time')
         ylabel('Slope')
         
 
         legend({['exp. fit, ' 'mean(|s|)=' num2str(coef) ', f_{init}=' num2str(f_init)]})%, ['analytic slope, ' 'mean(|s|)=' num2str(coef) ', f_{init}=' num2str(f_init)],'time'},'Location','northwest')
    title({['N=' num2str(N,'%-5.0e') ', L=' num2str(L)]  ; ['muL=' num2str(U)  ', Num runs=' num2str(run)]},'FontSize', 10)
    set(gca,'FontSize',30)
    set(gca,'linewidth',1.5)
    legend boxoff
    
   % save('f_init_01_mean_s_005.mat', 'C','slope_an')
    
  
         %%
        