
close all

C1=struct2array(load('f_init_02_mean_s_005.mat','C'));
slope_an_1=struct2array(load('f_init_02_mean_s_005.mat','slope_an'));
C3=struct2array(load('f_init_02_mean_s_01.mat','C'));

slope_an_wave_005=struct2array(load('analyt_wave_s_005.mat','sigma'));

slope_an_wave_01=struct2array(load('analyt_wave_s_01.mat','sigma'));


time_max=51;
t0=29; % start point for dashed lines

 figure(4)
 
   hold on





    
     
     h1=plot(0:time_max-1,-slope_an_1,'b','Linewidth',4) 
     h4=plot(0:time_max-1,-C1,'m','Linewidth',2)
     h5=plot(0:time_max-1,-C3,'m','Linewidth',1)
     
     h2=plot(t0:time_max,1./slope_an_wave_005(t0:time_max), 'b--','Linewidth',3)
     
     h3=plot(t0:time_max,1./slope_an_wave_01(t0:time_max), 'b--','Linewidth',3)
     
     plot(0:time_max-1,0:time_max-1,'g','Linewidth',2)

     
     hold off
     
       axis([0 50 0 50])
         
         
       axis square
       
       
        xlabel('Time')
         ylabel('Slope')
         
         legend([h1 h2 h3 h4 h5],{'analytic', 'analytic', 'analytic','simulation, s_{av}=0.05', 'simulation, s_{av}=0.1' },'FontSize', 25); 
        
%title({['N=' num2str(N,'%-5.0e') ', L=' num2str(L)]  ; ['muL=' num2str(U)  ', Num runs=' num2str(run)]},'FontSize', 10)
    set(gca,'FontSize',30)
    set(gca,'linewidth',1.5)
    legend boxoff