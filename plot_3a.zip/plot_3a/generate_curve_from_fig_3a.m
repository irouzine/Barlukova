close all
clear all     
%clc





% Parameters
global L Ee EE  s0 k0_init N U t E_st DATA    %#ok<TLEV>
t =25;   % Number of generetions
run=4;   % Number of runs

col = 'rbcgmk';  




L = 100;        % Number of sites per genome
N = 1e4;        % Number of genomes
coef=0.05;      % Average selection coefficient

sigma=coef*sqrt(pi/2);  % standard deviation for half gaussian distribution

s0 = 10;        % is not needed here: we use 'half' distribution
a = 0;          % percentage of beneficial. Here all mutations are deleterious.
     

U = 0.05;     
muL = U;        % per genome
mu=muL/L;       % per site

%% define EPISTATIC TOPOLOGY is not needed here

E_st = 0; % no epistasis

EE = zeros(L,L);

for i = 2:2:L                    %% 2 is <p> = 1, increase to skip pairs 
    EE(i,i-1) = 1; 
    EE(i-1,i) = 1;
end

Ee = tril(EE,-1);                % lower triangular matrix

%%


% f_init is initial mutation frequency per site over population 

f_init=0.2;  % initial value of mutant frequency per site

 k0_init= f_init*L;

 %Initialization
 
ww_r=zeros(N,t,run);
ww_mean_run=zeros(N,t);

W_r=zeros(t,run);
fw_r=zeros(t,run);
f_r=zeros(t,run);

F1_r=zeros(L,t,run);
F0_r=zeros(L,t,run);

F1 = zeros(L,t); 
F0 = zeros(L,t);

beta_r=zeros(t,run);


W=zeros(1,t);
f=zeros(1,t);
fw=zeros(1,t);
beta=zeros(1,t);
slope_an=zeros(1,t);
slope_f_beta=zeros(1,t);

F1_all_mean=zeros(run,L);

minFitness=zeros(1,t);

f_s=zeros(L,t);

f_beta=zeros(L,t);

f_an=zeros(L,t);


f_w_s=zeros(N,t);
beta_s=zeros(N,t);
f_f0_s=zeros(N,L,t);
f_s_r=zeros(L,t,run);

load('myrng.mat');


%ss=rng('shuffle');
                                                                
    for r=1:run
    
%rand('seed', 1);
      
      disp("run " + r)
    
        % ww - vector of genome fitness
        % S - vector of selection coefficients
        % DATA - 3D binary matrix of genomes (0 - best fit allele, 1 - less
        % fit allele) over time
    
        [DATA, ww, S] = evolution_code('half',  s0,  a, L, N,  t,  2,   U, k0_init , 1 , E_st, Ee, coef,ss);   


% Check which regime 

        c_1 = N * (mu/abs(mean(S)))^2;
        
        SUlogNs = abs(mean(S))/(mu*L)*log(N*abs(mean(S)));


        for time=1:t 
            
            

            
            
            
            ww_r(:,time,r) = ww(:,time);   
            
            fw_s(:,time) = abs(ww(:,time)./(mean(S)*L));
            
            beta_s(:,time) = sqrt(2/(pi*(-mean(S))^2).*1./fw_s(:,time)); 

            W_r(time,r) = mean(ww(:,time));                 % Average fitness over population
            fw_r(time,r) = abs(W_r(time,r)./(mean(S)*L));   % Fitness frequency normalized by selec coef
            %K(:,:,:) = DATA(:,:,:);                    % Sequences


            for jj = 1:L
    
                    F1_r(jj,time,r) = length(find(DATA(:,jj,time)==1))/N;
                    F0_r(jj,time,r) = 1-F1_r(jj,time,r);
                    

                    f_f0_s(:,jj,time)=exp(beta_s(:,time).*S(jj))./(1+exp(beta_s(:,time).*S(jj)));
            end
            
                 for jj = 1:L                
                    f_s_r(jj,time,r)=mean(f_f0_s(:,jj,time));
                    f_an(jj,time)=f_init./((1-f_init)*exp(-(time-1)*S(jj))+f_init);

                 end

                f_r(time,r) = mean(F1_r(:,time,r));  % Average frequency over sites
  
        end
        
        
     
    end
    
  %%  

    
    C=0; 
    A=0;
      

    
   

  for time=1:t

        W(time)=mean(W_r(time,:));          % Average fitness over genomes and runs
        f(time)=mean(f_r(time,:));          % Average frequency over sites and runs
        fw(time)=mean(fw_r(time,:));

    for jj=1:L
    
        F1(jj,time)=mean(F1_r(jj,time,:));
        F0(jj,time)=mean(F0_r(jj,time,:));
        
        f_s(jj,time)=mean(f_s_r(jj,time,:));  % Average analytic frequency over runs at each site

   
    end 
    
    for ii=1:N
         ww_mean_run(ii,time)=mean(ww_r(ii,time,:));

    end
    
    
   
    

                                                
ft = fittype('aa*exp(bb*x)');

f1fit = fit(-S',F1(:,time),ft);    % fitting data

fit_fs = fit(-S',f_s(:,time),ft);  % fitting analytics

slope_an(time)=fit_fs.bb;

sigma=coef*sqrt(pi/2);   % std for half normal 

A=vertcat(A,f1fit.aa);   

C=vertcat(C,f1fit.bb);   % slope from fitting data
 

       
    end


    %%
 %close all        
    
time = 10+1;  % time point to plot
    
x=[0, min(S)];

y=[mean(F1(:,time))*exp(-beta(time)*mean(S)), mean(F1(:,time))*exp(beta(time)*(min(S)-mean(S)))];
    
ft1_2 = fittype('a*x+b');

[f1fit, a1] = fit(-S',F1(:,time),ft); disp(f1fit)

YHat = f1fit(-S);

[f1fit_2,a1_2] = fit(-S',F1(:,time),ft1_2); 



h = figure(3); % Figure 3a in the paper



hold on


    scatter(-S,F1(:,time), 60,'LineWidth',2) 

    plot(-S,f_an(:,time),'g','Linewidth',3)
    
   
    text(-x(2),YHat(end),sprintf(['\\beta_{fit}=' num2str(C(time),'%.1f')]),'FontSize',20)


h=title({['| mean(s) |=' num2str(coef) ', N=' num2str(N,'%-5.0e') ', L=' num2str(L)]  ; ['muL=' num2str(U) ', f_{init}=' num2str(f_init)  ', Num runs=' num2str(run)]},'FontSize', 10)
xlabel('Mutation cost in fitness, \it s '), ylabel('Frequency of deleterious alleles'), axis square,
box off

legend boxoff
legend({['Simulation t = ' num2str(time-1)], ['Analytic prediction t = ' num2str(time-1)]},'Location','southwest','FontSize',25)

set(gca,'yscale','log') 
set(gca,'FontSize',25)
set(gca,'linewidth',1.5)
set(h,'FontSize',15)


%%
